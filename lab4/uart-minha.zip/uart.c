#include <lcom/lcf.h>
#include "uart_macros.h"
#include "fila.h"
#include "game.h"
#include "game_macros.h"
#include "i8042.h"
#include "i8254.h"

static int uart_hook_id = 4;



int transmit_queue(boot_resources *start){

  int contador_bytes=0;
  uint32_t aux_sender=INITIALIZE0;
  unsigned char *carater;

  while( (fila_tamanho(start->fila_transmitter)>0) && contador_bytes<16){
    
    carater=fila_front(start->fila_transmitter);

    if(carater==NULL){
      printf("Char Invalido\n");
      return -1;
    }

    aux_sender=*carater;

    sys_outb(TRANSMITTER_HOLDING_REG,aux_sender);
    
  }
  
  return 0;
}

int receive_queue(boot_resources *start){

  uint32_t leitura_aux=INITIALIZE0;
  unsigned char cast_auxiliar;

  int contador_bytes=0;

  while(sys_inb(RECEIVER_BUFFER_REG,&leitura_aux)==0){
    
    contador_bytes++;

    cast_auxiliar=leitura_aux;

    fila_push(start->fila_receiver,&cast_auxiliar);

  }
  
  printf("BYTES LIDOS %d \n",contador_bytes);

  return 0;
}

void self_clearing_receiver()
{
  uint32_t leitura;
  sys_inb(FIFO_CONTROL_REG, &leitura);
  leitura = leitura | BIT(1);
  sys_outb(FIFO_CONTROL_REG, leitura);

  return;
}

void self_clearing_transmitter()
{
  uint32_t leitura;
  
  sys_inb(FIFO_CONTROL_REG, &leitura);
  
  leitura = leitura | BIT(2);
  sys_outb(FIFO_CONTROL_REG, leitura);

}
int uart_subscribe_int(uint8_t *bit_no)
{

  uint32_t leitura;

  if (bit_no == NULL)
  { //erro caso a apontador bit no não seja valido
    return -1;
  }

  *bit_no = (uint8_t)uart_hook_id; // bit no recebe o hook id que nos configuramos para mandarmos para o kernel

  if (sys_irqsetpolicy(IRQ_UART_LINE, IRQ_REENABLE | IRQ_EXCLUSIVE, &uart_hook_id) != OK)
  { //da set a policy
    printf("ERRO , sys_irqsetpolicy falhou\n");
    return -1;
  }

  //Garantir DLAB a 0
  sys_inb(LINE_CONTROL_REG, &leitura);
  leitura=leitura & 0x7F;
  sys_outb(LINE_CONTROL_REG,leitura);

  //--------------- Dar enable aos interrupts---------------
  
  
  //sys_inb(INTERRUPT_ENABLE_REGISTER, &leitura);- Nao sei se e read, mais vale jogar pelo seguro.
  leitura=INITIALIZE0;

  leitura = leitura | (BIT(2) | BIT(1) | BIT(0)); // dar enable aos interrupts de dados,empty transmiter e receiver line status.
  sys_outb(INTERRUPT_ENABLE_REGISTER, leitura);

  //----------------Dar setup as configs, 8bits/char/1stop bit, parity 1---------

  sys_inb(LINE_CONTROL_REG, &leitura);
  leitura = leitura | BIT(0) | BIT(1) | BIT(3);
  leitura=leitura & 0xCB;
  leitura=leitura|DLAB_BIT_LOAD;

  sys_outb(LINE_CONTROL_REG, leitura);

  //-----------------Dar setup aos divisor latch-----------
  leitura = BIT(1);
  sys_outb(BASE_REG_COM1, leitura);
  
  leitura = 0x00;

  sys_outb(BASE_REG_COM1 + 1, leitura);

  //--------------Dar reset a config para poder ler dados, aceder ao LCR, BIT DLAB-----

  sys_inb(LINE_CONTROL_REG, &leitura);

  leitura = leitura & 0x7F;

  sys_outb(LINE_CONTROL_REG, leitura);

  //--------------Dar enable aos FIFOS e trigger level a 14-----------

  sys_inb(FIFO_CONTROL_REG, &leitura);

  leitura = leitura | (BIT(7) | BIT(6) | BIT(0) | BIT(1) | BIT(2));

  sys_outb(FIFO_CONTROL_REG, leitura);

  //Falta fazer func que chame um clear Transmiter e Receive FIFO
  
  //Checkar que o FIFO foi mesmo ativo. Aceder ao IIR, e testar o FIFO STATUS sector

  sys_inb(INTERRUPT_ID_REG, &leitura);
  
  if ((leitura & 0xC0) == 0)
  {

    printf("Erro a inicializar o FIFO\n");
    return -1;
  }
  else
  {
    printf("Tudo ok, FIFO Working\n");
  }

  //Verificar que o DLAB está mesmo off
  sys_inb(LINE_CONTROL_REG,&leitura);

  if((leitura&0x80)!=0){
    printf("DLAB ATIVO ALERTA\n");
  }

  return 0;
}


int uart_ih(boot_resources *start)
{

  uint32_t leitura;
  uint32_t leitura_line_status;
  sys_inb(INTERRUPT_ID_REG, &leitura);

  if ((leitura & BIT(0)) == 0x01)
  {
    printf("ERRO: no interrupts is pending\n");
    return -1;
  }

  leitura = leitura & (BIT(3) | BIT(2) | BIT(1));
  leitura = leitura >> 1;
  
  printf("leitura %d \n", leitura);

  switch (leitura)
  {
  
  case 0:
    printf("MODEM - ERRO\n");
  break;
  //transmitter holding register empty. Aqui vou passar para o Buffer a queue que tenho neste momento até 16 bits
  case 1:

    if (transmit_queue(start) == -1)
    {
      printf("Erro ao transmitir a fila\n");
      return -1;
    }

    break;

  //received  data available
  case 2:

    if (receive_queue(start) == -1)
    {
      return -1;
    }

    break;

  //receiver line status
  case 3:

    sys_inb(LINE_STATUS_REG, &leitura_line_status);

    if (leitura & (BIT(1) | BIT(2) | BIT(3)))
    {
      printf("ERRO, overrun error or parity error or framing error\n");
      return -1;
    }
    break;

  //character timeout
  case 6:

    printf("character time out \n");

    if (receive_queue(start) == -1)
    {
      return -1;
    }
    printf("\n");

    break;
  }
  return 0;
}

int uart_unsubscribe_int()
{

  uint32_t leitura;

  if (sys_irqdisable(&uart_hook_id) != OK)
  { //disable primeiro, para depois tirar a policy set
    printf("ERRO , sys_irqdisable falhou\n");
    return -1;
  }
  //------------- Da Disable no HW ao hardware

  sys_inb(INTERRUPT_ENABLE_REGISTER, &leitura);

  leitura = leitura & (BIT(7) | BIT(6) | BIT(5) | BIT(4) | BIT(3));

  sys_outb(INTERRUPT_ENABLE_REGISTER, leitura);

  //-----------Da disable aos FIFOS

  sys_inb(FIFO_CONTROL_REG, &leitura);

  leitura = leitura & (BIT(7) | BIT(6) | BIT(5) | BIT(4) | BIT(3));

  sys_outb(FIFO_CONTROL_REG, leitura);

  //Falta chamar a func clear

  if (sys_irqrmpolicy(&uart_hook_id) != OK)
  { //disbable nos interrupts
    printf("ERRO , sys_irqrmpolicy falhou\n");
    return -1;
  }

  return 0;
}
