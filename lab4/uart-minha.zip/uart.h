#pragma once

struct boot_resources;

int uart_subscribe_int(uint8_t *bit_no);
void self_clearing_receiver();
void self_clearing_transmitter();
int uart_unsubscribe_int();
int uart_ih(boot_resources *start);
int receive_queue(boot_resources *start);
int transmit_queue(boot_resources *start);

